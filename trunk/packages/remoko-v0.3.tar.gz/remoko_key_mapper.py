

class key_mapper:
	
	def __init__(self):
		
		self.mapper = {}
		
		self.mapper['a'] = 4
		self.mapper['b'] = 5
		self.mapper['c'] = 6
		self.mapper['d'] = 7
		self.mapper['e'] = 8
		self.mapper['f'] = 9
		self.mapper['g'] = 10
		self.mapper['h'] = 11
		self.mapper['i'] = 12
		self.mapper['j'] = 13
		self.mapper['k'] = 14
		self.mapper['l'] = 15
		self.mapper['m'] = 16
		self.mapper['n'] = 17
		self.mapper['o'] = 18
		self.mapper['p'] = 19
		self.mapper['q'] = 20
		self.mapper['r'] = 21
		self.mapper['s'] = 22
		self.mapper['t'] = 23
		self.mapper['u'] = 24
		self.mapper['v'] = 25
		self.mapper['w'] = 26
		self.mapper['x'] = 27
		self.mapper['y'] = 28
		self.mapper['z'] = 29  
		
		self.mapper['1'] = 30
		self.mapper['2'] = 31
		self.mapper['3'] = 32
		self.mapper['4'] = 33
		self.mapper['5'] = 34
		self.mapper['6'] = 35
		self.mapper['7'] = 36
		self.mapper['8'] = 37
		self.mapper['9'] = 38
		self.mapper['0'] = 39
		self.mapper['Return'] = 40
		self.mapper['Escape'] = 41 
		self.mapper['BackSpace'] = 42
		self.mapper['Tab'] = 43
		self.mapper['space'] = 44
		self.mapper['minus'] = 45
		self.mapper['equal'] = 46 
		self.mapper['bracketleft'] = 47
		self.mapper['bracketright'] = 48
		self.mapper['backslash'] = 49
		
		self.mapper['semicolon'] = 51
		self.mapper['apostrophe'] = 52
		self.mapper['grave'] = 53
		self.mapper['comma'] = 54
		self.mapper['period'] = 55
		self.mapper['slash'] = 56
		
		self.mapper['Insert'] = 73
		self.mapper['Home'] = 74
		self.mapper['Prior'] = 75
		self.mapper['Delete'] = 76
		self.mapper['End'] = 77
		self.mapper['Next'] = 78
		self.mapper['Right'] = 79
		self.mapper['Left'] = 80
		self.mapper['Down'] = 81
		self.mapper['Up'] = 82
		
		
		
		#self.mapper['minus'] = 86
		
		
		
